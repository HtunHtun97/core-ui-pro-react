module.exports = [
	{ github: 'jedwatson', name: 'Jed Watson' },
	{ github: 'bruderstein', name: 'Dave Brotherstone' },
	{ github: 'jossmac', name: 'Joss Mackison' },
	{ github: 'jniechcial', name: 'Jakub Niechciał' },
	{ github: 'craigdallimore', name: 'Craig Dallimore' },
	{ github: 'julen', name: 'Julen Ruiz Aizpuru' },
	{ github: 'dcousens', name: 'Daniel Cousens' },
	{ github: 'jgautsch', name: 'Jon Gautsch' },
	{ github: 'dmitry-smirnov', name: 'Dmitry Smirnov' },
];
