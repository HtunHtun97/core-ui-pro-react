import React from 'react'

const Dashboard = () => {
  return (
    <>
      Hello world!
    </>
  )
}

export default Dashboard
