import React from 'react'

declare module 'react' {
  let icons: { [key: string]: string | Array<string> }
}
